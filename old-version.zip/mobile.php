<?php include('includes/header.php'); ?>
	<body>
		<section style="height: 100%; width: 100%;">
			<article style="position: absolute; left: 50%; top: 50%; transform: translateX(-50%) translateY(-50%);">
				<center>
					<img src="image/logo.png" /><br/>
					<h1>Para acessar o conteúdo deste site, por favor, use um desktop.</h1>
				</center>
			</article>
		</section>
	</body>
</html>