<?php
	error_reporting(0);
	$paragrafos = (int) $_POST['paragrafos'];
	$l = 0;
	if ($paragrafos > 0) {
		$file = file_get_contents('./text.json');
		$data = json_decode($file, true);
		$result = array();
		if($paragrafos > 5){
			for ($i = 0; $i < $paragrafos; $i++) {
				$l += 0; 
				if($l == 5){
					$l -= 5;
				}
				$result[] = $data[$l];
				$l++;
			}
		}		
		else{
			for ($i = 0; $i < $paragrafos; $i++) {
				$l += 0;
				$result[] = $data[$l];
				$l++;
			}
		}
	}
	if (count($result) > 0):
	foreach($result as $r):
	echo($r);
	endforeach;
	endif;
?>