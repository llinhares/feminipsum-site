<?php include('includes/header.php'); ?>
	<body>
		<section id="container" class="no_bg">
			<div id="menu_about"><p><a href="index.php"><img src="image/logo.png" /></a></p></div>
			<article id="about" class="content vcenter_hcenter">
				<p class="text_about">
					Piadas machistas, discriminação e assédio sexual. Esses<br/>
					são alguns dos comportamentos que mulheres que trabalham<br/>
					na criação das agências de publicidade enfrentam todos os dias.<br/>
					O <span style="color: #eb224c;">Domina</span> surgiu pra ajudar a combater tudo isso. Nossa<br/>
					ideia é criar ações como o Feminipsum, que gerem um debate<br/>
					sobre o machismo e a falta de mulheres na propaganda.<br/>
					<a href="https://www.facebook.com/projetodomina/" class="fade_transition"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				</p>
			</article>
		</section>
	</body>
</html>