<!doctype html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>FEMINIPSUM</title>
		<meta name="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="Description" content="Para combater o machismo. Nenhum caractere será desperdiçãdo." />
		<meta name="Keywords" content="palavra-chave-separada-por-virgula">
		<meta Name=”robots” content=”index,follow”>
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<!--[if IE]><link rel="shortcut icon" href="image/favicon/favicon.ico"><![endif]-->
		<link rel="icon" href="image/favicon/favicon-16.png" sizes="16x16">
		<link rel="icon" href="image/favicon/favicon-32.png" sizes="32x32">
		<link rel="icon" href="image/favicon/favicon-48.png" sizes="48x48">
		<link rel="icon" href="image/favicon/favicon-64.png" sizes="64x64">
		<link rel="icon" href="image/favicon/favicon-128.png" sizes="128x128">
		<link rel="icon" href="image/favicon/favicon-256.png" sizes="256x256">
		<!-- iPad iOS7+ com Retina Display -->
		<link rel="apple-touch-icon" sizes="152x152" href="image/favicon/apple-touch-icon-152x152.png">
		<!-- iPad iOS7- com Retina Display -->
		<link rel="apple-touch-icon" sizes="144x144" href="image/favicon/apple-touch-icon-144x144.png">
		<!-- iPhone iOS7+ com Retina Display -->
		<link rel="apple-touch-icon" sizes="120x120" href="image/favicon/apple-touch-icon-120x120.png">
		<!-- iPhone iOS7- com Retina Display -->
		<link rel="apple-touch-icon" sizes="114x114" href="image/favicon/apple-touch-icon-114x114.png">
		<!-- iPad iOS7+ sem retina display e iPad Mini-->
		<link rel="apple-touch-icon" sizes="76x76" href="image/favicon/apple-touch-icon-76x76.png">
		<!-- iPad iOS7- sem retina display  -->
		<link rel="apple-touch-icon" sizes="72x72" href="image/favicon/apple-touch-icon-72x72.png">
		<!-- iPhone iOS7-, iPod Touch e Android 2.2+  -->
		<link rel="apple-touch-icon" href="image/favicon/apple-touch-icon.png">
		<!-- Windows 8  -->
		<meta name="msapplication-TileImage" content="image/favicon/tile.png"/>
		<meta name="msapplication-TileColor" content="#151515"/>
		<script>var altura =  window.innerHeight + 10px; document.write("<style type='text/css'>#logo{{top:"+altura+"px;}</style>");</script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script type="text/javascript">
			function gerar() {
				$.ajax({
					type: "POST",
					url: "library/text_generate.php",
					data: {
						paragrafos: $('#paragrafos').val()
					},
					success: function(data) {
						$('#box_text').html(data);
					}
				});
			}
		</script>
		<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-106192724-1', 'auto');
			ga('send', 'pageview');
		</script>
	</head>