<?php include('includes/header.php'); ?>
	<body>
		<?php
			// Include and instantiate the class.
			require_once 'library/Mobile_Detect.php';
			$detect = new Mobile_Detect;

			// Any mobile device (phones or tablets).
			if ( $detect->isMobile() ) {
				//header("Location: mobile.php");
				echo '<script type="text/javascript">window.location.replace("mobile.php");</script>';
			}
		?>
		<section id="container">
			<div id="menu_about"><p><a href="about.php">About</a></p></div>
			<article id="about" class="content vcenter_hcenter">
				<div id="frase_header"><p>PARA ACABAR<br/>COM O MACHISMO,<br/>NENHUM CARACTERE<br/>SERÁ DESPERDIÇADO.</p></div>
			</article>
			<article id="text_generator" class="content_genertor">
				<div id="logo"><p><img src="image/logo.png" /></p></div>
				<div id="box_align">
					<div id="text_controls" method="post">
						<div><input type="submit" id="gerar" onClick="gerar()" value="gerar texto" hidden></div>
						<div><span class="border_input"><h7 class='number-wrapper'><input onClick="gerar()" type="number" id="paragrafos" name="paragrafos" value="1" min="1"></h7></span><span><div style="float: left; margin: 0; height: 4px; width: 30%;"></div>PARAGRÁFO(S)</span></div>
					</div>
					<div id="box_text">
						<p>Lorem Ipsum é que nem os comportamentos machistas dentro da criação. Você não presta atenção, só sai reproduzindo por aí. Mas também, pra que levar a sério um texto que não diz nada ou mulheres que são minoria? Afinal, elas somam só 20% da criação. Um número inversamente proporcional a todas as piadas de cunho machista e sexual que elas escutam todos os dias. Sim, todos os dias.</p>
					</div>
				</div>
			</article>
		</section>
	</body>
</html>