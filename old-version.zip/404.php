<?php include('includes/header.php'); ?>
	<body>
		<section id="container" class="no_bg">
			<div id="menu_about"><p><a href="index.php"><img src="image/logo.png" /></a></p></div>
			<article id="about" class="content vcenter_hcenter">
				<center style="font-size: 6em; font-weight: bold;position: relative;top: 50%;transform: translateY(-50%);">
					404
				</center>
			</article>
		</section>
	</body>
</html>